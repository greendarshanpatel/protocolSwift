//
//  DetailViewController.swift
//  ProtocolDemo
//
//  Created by agilemac-74 on 09/08/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

@objc protocol detailValueChangedDelegate {
    func changeValueAtIndex(replaceIndex : NSInteger,dict : NSDictionary) -> Void
    @objc optional func optionlMethodHere()
}
class DetailViewController: UIViewController {

    var delegate : detailValueChangedDelegate?
    var selectedIndex : NSInteger = 0
    var dictValue : NSMutableDictionary = NSMutableDictionary()
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func valueChangeIndex(_ sender: Any)
    {
        dictValue.setValue("Sachin", forKey: "Fn")
        self.delegate?.changeValueAtIndex(replaceIndex: selectedIndex, dict: dictValue)
        
        self.delegate?.optionlMethodHere?()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
