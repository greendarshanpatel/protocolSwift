//
//  FeedlistViewController.swift
//  ProtocolDemo
//
//  Created by agilemac-74 on 09/08/17.
//  Copyright © 2017 Agile. All rights reserved.
//

import UIKit

class FeedlistViewController: UIViewController,detailValueChangedDelegate {

    let arrObjects : NSMutableArray = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
        arrObjects.add(self.prepareDict(value1: "Micheal", value2: "black"))
        arrObjects.add(self.prepareDict(value1: "B", value2: "John"))
        arrObjects.add(self.prepareDict(value1: "P", value2: "a"))
        arrObjects.add(self.prepareDict(value1: "Kane", value2: "William"))
        
        print(arrObjects)
    }
    func prepareDict(value1 :String ,value2 : String)-> NSMutableDictionary{
        let dict : NSMutableDictionary = NSMutableDictionary()
        dict.setValue(value1, forKey: "Fn")
        dict.setValue(value2, forKey: "Ln")

        return dict as NSMutableDictionary
    }
    @IBAction func btnDetailPressed(_ sender: Any)
    {
        let viewDetail = DetailViewController(nibName: "DetailViewController", bundle: nil)
        viewDetail.selectedIndex = 2
        viewDetail.dictValue = arrObjects.object(at: 2) as! NSMutableDictionary
        viewDetail.delegate = self
        self.navigationController?.pushViewController(viewDetail, animated: true)
    }
    //MARK: Delegate method
    func changeValueAtIndex(replaceIndex: NSInteger, dict: NSDictionary) {
        print(arrObjects)
        
        print(replaceIndex)
        print(dict)
        arrObjects.replaceObject(at: replaceIndex, with: dict)
        print(arrObjects)
    }
    
}
